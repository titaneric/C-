#include <iostream>
#include "ExtremaList.h"
using namespace std;
int main() {
	double Ad[6] = { 12.1, 5.6, 89.0, 4.0, 1.567, 9.01 };
	ExtremaList<double> exL1(6, Ad), exL2;
	cout << exL1 << endl;
	cout << "max: " << exL1.max() << endl;
	cout << "min: " << exL1.min() << endl;
	cout << exL2 << endl;
	cout << "max: " << exL2.max() << endl;
	cout << "min: " << exL2.min() << endl;
	cout << endl;		int Ai[4] = { 3, 6, 1, -10 };
	ExtremaList<int> exL3(4, Ai), exL4 = exL3;
	exL4.push_back(99);
	exL4.push_back(-99);
	
	cout << exL3 << endl;
	cout << "max: " << exL3.max() << endl;
	cout << "min: " << exL3.min() << endl;
	cout << exL4 << endl;
	cout << "max: " << exL4.max() << endl;
	cout << "min: " << exL4.min() << endl;
	cout << endl;
	exL3.pop_back();
	exL4.clear();
	cout << exL3 << endl;
	cout << "max: " << exL3.max() << endl;
	cout << "min: " << exL3.min() << endl;
	cout << exL4 << endl;
	cout << "max: " << exL4.max() << endl;
	cout << "min: " << exL4.min() << endl;


	//system("pause");
	return 0;
}