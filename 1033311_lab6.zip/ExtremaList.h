#pragma once
#include<list>
#include<algorithm>
#include<limits>
using namespace std;
template <class T>
class ExtremaList: public list<T>{
public:
	//Empty CTOR
	ExtremaList() :list<T>() {};
	//Range CTOR
	template <class TItr>
	ExtremaList(TItr itrBegin, TItr itrEn) :list<T>(itrBegin, itrEn) {};
	//Special CTOR
	template <class TItr>
	ExtremaList(size_t size, TItr itrBegin) : list<T>(itrBegin, itrBegin + size) {};
	//Copy CTOR
	ExtremaList(const ExtremaList&el) :list<T>(el) {};
	const T& max() const {
		if (this->size() == 0) {
			T max_value = numeric_limits<T>::max();
			return max_value;
		}
		else {
			T max_value = *max_element(this->begin(), this->end());
			return max_value;
		}
	};
	const T& min() const {
		if (this->size() == 0) {
			T min_value = numeric_limits<T>::lowest();
			return min_value;
		}
		else {
			T min_value = *min_element(this->begin(), this->end());
			return min_value;
		}
	};
	
};
template<class T>
ostream& operator <<(ostream& ostr, const ExtremaList<T>& el) {
	for (auto i = el.begin(); i != el.end(); i++) {
		ostr << *i << " ";
	}
	return ostr;
}