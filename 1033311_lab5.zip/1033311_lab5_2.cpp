#include"Stack.h"
#include<iostream>
using namespace std;
void stackSort(Stack &s);
void sortInsert(Stack &s, int element);
int main() {
	int element;
	Stack s;
	while (!s.isFull() && cin >> element) {
		s.push(element);
		stackSort(s);
		s.out();
	}
	

	//system("pause");
	return 0;
}
void stackSort(Stack &s)
{
	if (!s.isEmpty()) {
		int temp = s.top();
		s = s.pop();
		stackSort(s);
		sortInsert(s, temp);
	}


}
void sortInsert(Stack &s, int element)
{
	if (!s.isEmpty()) {
		int temp = s.top();
		if (element < temp) {
			s = s.pop();
			sortInsert(s, element);
			s.push(temp);
		}
		else {
			s.push(element);
		}
	}
	else {
		s.push(element);
	}
}

