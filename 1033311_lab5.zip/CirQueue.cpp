#include "CirQueue.h"

using namespace std;

CirQueue::CirQueue(size_t cap):
m_front(0), m_rear(cap - 1), m_n(0),
m_capacity(cap),
m_data( cap == 0 ? nullptr: new Item[cap]{} )
{}

CirQueue::~CirQueue(){ delete m_data; }

CirQueue& CirQueue::push(const CirQueue::Item& x){
    if(!isFull()){
        m_rear = (m_rear + 1) % m_capacity;
        m_data[m_rear] = x;
        ++m_n;
    }
    return *this;
}

CirQueue& CirQueue::pop(){
    if(!isEmpty()){
        m_front = (m_front + 1) % m_capacity;
        --m_n;
    }
    return *this;
}

void CirQueue::out() const{
    cout << "N = " << m_n << ": ";
    for(size_t i = 0, j = m_front; i < m_n;){
        cout << m_data[j++];
        ++i;
        if(i < m_n) cout << ", ";
        j %= m_capacity;
    }
    cout << endl;
}