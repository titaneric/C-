#include"QStack.h"
#include<iostream>
using namespace std;
void stackSort(QStack &s);
void sortInsert(QStack &s, int element);
int main() {
	/*Test data*/
	QStack stack;
	stack.push(1);
	stack.push(2);
	stack.push(0);
	stack.push(4);
	stack.out();
	//stackSort(stack);
	stack.pop();
	stack.out();


	//system("pause");
	return 0;
}
/*Test for the lab5_2 and lab5_3*/
void stackSort(QStack &s)
{
	if (!s.isEmpty()) {
		int temp = s.top();
		s = s.pop();
		stackSort(s);
		sortInsert(s, temp);
	}


}
void sortInsert(QStack &s, int element)
{
	if (!s.isEmpty()) {
		int temp = s.top();
		if (element < temp) {
			s = s.pop();
			sortInsert(s, element);
			s.push(temp);
		}
		else {
			s.push(element);
		}
	}
	else {
		s.push(element);
	}
}
