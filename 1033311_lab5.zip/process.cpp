#include "process.h"

void Process::stateTransition(char activity)
{
	switch (activity)
	{
		/*ADMIT*/
	case 'a':
		this->admit();
		break;
	case 'A':
		this->admit();
		break;
		/*INTERRUPT*/
	case 'i':
		this->interrupt();
		break;
	case 'I':
		this->interrupt();
		break;
		/*DISPATCH*/
	case 'd':
		this->dispatch();
		break;
	case 'D':
		this->dispatch();
		break;
		/*WAIT*/
	case 'w':
		this->wait();
		break;
	case 'W':
		this->wait();
		break;
		/*EXIT*/
	case 'E':
		this->exit();
		break;
	case 'e':
		this->exit();
		break;
	default:
		cout << "Wrong activity!\n";
		this->nothingChange();
		break;
	}
}

void Process::nothingChange()
{
	cout << "NOTHING HAPPENED\n";
	cout << "State change:";
	switch (this->currentState())
	{
	case State::New:
		cout << "NEW -> New\n";
		break;
	case State::Ready:
		cout << "READY -> READY\n";
		break;
	case State::Running:
		cout << "RUNNING -> RUNNING\n";
		break;
	case State::Terminated:
		cout << "TERMINATED -> TERMINATED\n";
		break;
	case State::Waiting:
		cout << "WAITING -> WAITING\n";
		break;
	default:
		break;
	}
}
void Process::admit() {
	if (this->currentState() == State::New) {
		cout << "ADMIT activity\n";
		cout << "State change: NEW -> READY\n";
		this->updateState(State::Ready);
	}
	else if (this->currentState() == State::Waiting) {
		cout << "ADMIT activity\n";
		cout << "State change: WAITING -> READY\n";
		this->updateState(State::Ready);
	}
	else
		this->nothingChange();
}
void Process::interrupt() {
	if (this->currentState() == State::Running) {
		cout << "INTERRUPT activity\n";
		cout << "State change: RUNNING -> READY\n";
		this->updateState(State::Ready);
	}
	else
		this->nothingChange();
}
void Process::dispatch() {
	if (this->currentState() == State::Ready) {
		cout << "DISPATCH activity\n";
		cout << "State change: READY -> RUNNING\n";
		this->updateState(State::Running);
	}
	else
		this->nothingChange();
}
void Process::wait() {
	if (this->currentState() == State::Running) {
		cout << "WAIT activity\n";
		cout << "State change: RUNNING -> WAITING\n";
		this->updateState(State::Waiting);
	}
	else
		this->nothingChange();
}
void Process::exit() {
	if (this->currentState() == State::Running) {
		cout << "EXIT activity\n";
		cout << "State change: RUNNING->TERMINATED\n";
		this->updateState(State::Terminated);
	}
	else
		this->nothingChange();
}
void Process::displayState() {
	cout << "Current state:";
	switch (this->currentState())
	{
	case State::New:
		cout << "NEW\n";
		break;
	case State::Ready:
		cout << "READY\n";
		break;
	case State::Running:
		cout << "RUNNING\n";
		break;
	case State::Terminated:
		cout << "TERMINATED\n";
		break;
	case State::Waiting:
		cout << "WAITING\n";
		break;
	default:
		break;
	}
}