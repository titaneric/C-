#include "QStack.h"
QStack & QStack::push(const Item & x)
{
	int formerSize = this->size();
	q.push(x);
	for (int i = 0; i < formerSize; i++) {
		int front = this->top();
		q.push(front);
		q.pop();
	}
	return *this;
}

QStack & QStack::pop()
{
	if (!isEmpty()) {
		q.pop();
	}
	return *this;
}

void QStack::out() const
{
	q.out();
}


