#ifndef CirQueue_H
#define CirQueue_H

#include <iostream>

class CirQueue{
public:
    typedef float Item;
private:
    Item * m_data;
    size_t m_front, m_rear, m_n, m_capacity;
public:
    CirQueue(size_t cap = 5);
    ~CirQueue();
    inline bool isEmpty() const{ return m_n == 0; }
    inline bool isFull() const{ return m_n >= m_capacity;}
    inline size_t size() const{ return m_n; }
    inline const Item& front()const{ return m_data[m_front];}
    CirQueue& push(const Item& x);
    CirQueue& pop();
    void out() const;
};

#endif /* defined(CirQueue_H) */
