#include "Stack.h"
#include <iostream>
using namespace std;

// ctor
Stack::Stack(size_t cap):
m_top(numeric_limits<size_t>::max()),
m_cap(cap), m_size(0),
m_data(m_cap == 0 ? nullptr : new Item[m_cap]{} )
{}

// Copy ctor
Stack::Stack(const Stack& s):
m_top(s.m_top),
m_cap(s.m_cap), m_size(s.m_size),
m_data(s.m_cap == 0 ? nullptr : new Item[s.m_cap]{} )
{
    for(size_t i = 0; i < m_size; ++i)
        m_data[i] = s.m_data[i];
}
//dtor
Stack::~Stack(){ delete [] m_data; }


// push
Stack& Stack::push(){
    if(!isFull()) {
        ++m_top;
        ++m_size;
    }
    return *this;
}

// push
Stack& Stack::push(const Item& x){
    if(!isFull()) {
        m_data[++m_top] = x;
        ++m_size;
    }
    return *this;
}

// pop
Stack& Stack::pop() {
    if(!isEmpty()){
        --m_top;
        --m_size;
    }
    return *this;
}

// output
void Stack::out()const {
    cout << "STACK N = " << m_size << ": ";
    for(size_t i = 0; i < m_size;){
        cout << m_data[i++];
        if(i < m_size) cout << ", ";
    }
    cout << endl;
}