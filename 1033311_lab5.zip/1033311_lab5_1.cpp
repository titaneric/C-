#include"process.h"
#include<iostream>
using namespace std;
int main() {
	Process process;
	char activity;
	while (cin >> activity) {
		process.setActivity(activity);
		process.displayState();
		if (process.terminatedListenser())
			break;
	}



	//system("pause");
	return 0;
}