
#ifndef STACK_H
#define STACK_H
#include <iostream>

class Stack{
public:
    typedef int Item;
private:
    size_t m_top, m_size, m_cap;
    Item * m_data;
public:
    Stack(size_t cap = 10); 	// default ctor
    Stack(const Stack& s);		// copy ctor
    ~Stack();				// dtor
    inline size_t capacity() const {return m_cap;}
    inline size_t size() const {return m_size;}
    inline bool isEmpty() const {return m_size == 0;}
    inline bool isFull() const {return m_size == m_cap;}
    inline const Item& top() const {return m_data[m_top];}
    inline Item& top() {return m_data[m_top];}    
    Stack& push();
    Stack& push(const Item& x);
    Stack& pop();
    void out()const;
};

#endif /* defined(STACK_H) */
