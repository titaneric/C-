#pragma once
#include<iostream>
using namespace std;
enum class State:int
{
	New, Ready, Running, Waiting, Terminated
};
class Process {
private:
	State p_currentState = State::New;
	char p_activity;
	State currentState()const { return this->p_currentState; }
	char activity()const { return this->p_activity; }
	void updateState(State newState) { this->p_currentState = newState; }
	void stateTransition(char activity);
	void nothingChange();
	void admit();
	void dispatch();
	void wait();
	void interrupt();
	void exit();
public:
	void setActivity(char newActivity) { this->p_activity = newActivity; this->stateTransition(this->activity()); }
	void displayState();
	bool terminatedListenser() { if (this->currentState() == State::Terminated)return true; else return false; }
};
