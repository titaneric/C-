#pragma once
#include"CirQueue.h"
#ifndef QStack_H
#define QStack_H
class QStack {
public:
	typedef int Item;
private:
	CirQueue q;
public:
	//inline size_t capacity() const { return q.m_cap; }
	inline size_t size() const { return q.size(); }
	inline bool isEmpty() const { return q.isEmpty(); }
	inline bool isFull() const { return q.isFull(); }
	inline const Item& top() const { return q.front(); };
	//inline Item& top() { return q.front(); };
	QStack& push(const Item& x);
	QStack& pop();
	void out()const;

};
#endif